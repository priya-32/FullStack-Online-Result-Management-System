import logo from './logo.svg';
import './App.css';
import Navbar from './Components/Navbar';
import {Routes, Route } from "react-router-dom"
import Mainpage from './Pages/Mainpage';
import Home from './Pages/Home';
import SocialShareMenu from './Pages/SocialShareMenu';
import Aboutus from './Pages/Aboutus';
import { ContactUs } from './Pages/Contactus';
import BlogList from './Pages/BlogList';
import Department from './Pages/department';
import Academics from './Pages/Academics';
import LoginForm from './Pages/Login';
import Register from './Pages/Register';
import UserPanel from './Pages/Student/UserPanel/UserPanel';
import Faq from './Faq';
import PrivacyPolicy from './Pages/PrivacyPolicy';
import TermsAndConditions from './Pages/TermsAndConditions';
import { UserAuth } from './Pages/Student/Auth/UserAuth';
import ViewStudent1 from './Pages/Student/ViewStudent';
import ViewResult1 from './Pages/Student/ViewResult';
import ViewSubject1 from './Pages/Student/ViewSubject1';
import Addfeedback from './Pages/Student/Addfeedback';
import { AdminAuth } from './Pages/Admin/Auth/AdminAuth';
import AddStudent from './Pages/Admin/Student/AddStudent';
import ViewStudent from './Pages/Admin/Student/ViewStudent';
import EditSubject from './Pages/Admin/Subject/EditSubject';
import AddResult from './Pages/Admin/Result/AddResult';
import ViewResult from './Pages/Admin/Result/ViewResult';
import EditResult from './Pages/Admin/Result/EditResult';
import EditStudent from './Pages/Admin/Student/EditStudent';
import AddSubject from './Pages/Admin/Subject/AddSubject';
import ViewSubject from './Pages/Admin/Subject/ViewSubject';
import ViewFeedback from './Pages/Admin/Feedback/ViewFeedback';
import AdminPanel from './Pages/Admin/AdminPanel/AdminPanel';

function App() {
  return (
    <div className="App">

      <Routes>
        
<Route path = "/" element = {<Home/>}/>
<Route path = "/contact" element = {<ContactUs/>}/>
<Route path = "/about" element = {<Aboutus/>}/>
<Route path='/blog' element = {<BlogList/>}/>
<Route path = "/academics" element = {<Academics/>}/>
<Route path = "/login" element = {<LoginForm/>}/>
      <Route  path='/register' element={<Register />} />

      <Route element={<AdminAuth />}>
      <Route exact path = "/admin/dashboard" element = {<AdminPanel/>}/>
      <Route exact path='/admin/student/add' element={<AddStudent />} />
      <Route exact path='/admin/student/view' element={<ViewStudent />} />
      <Route exact path='/admin/student/edit/:sId' element={<EditStudent />} />
      <Route exact path='/admin/subject/addSub' element={<AddSubject />} />
      <Route exact path='/admin/subject/view' element={<ViewSubject />} />
      <Route exact path='/admin/subject/edit/:subId' element={<EditSubject />} />
      <Route exact path='/admin/result/addRes' element={<AddResult />} />
      <Route exact path='/admin/result/viewRes' element={<ViewResult />} />
      <Route exact path='/admin/result/edit/:resId' element={<EditResult />} />
      <Route exact path='/admin/feedback/viewFeed' element={<ViewFeedback />} />

      </Route>
      <Route element={<UserAuth />}>
          <Route exact path="/user/dashboard" element={<UserPanel />} />
          <Route exact path='/user/student/view' element={<ViewStudent1 />} />
          <Route exact path='/user/result/view' element={<ViewResult1 />} />
          <Route exact path='/user/subject/view' element={<ViewSubject1 />} />
          <Route exact path='/user/feedback/add' element={<Addfeedback />} />
        </Route>
      <Route path = "/faq" element = {<Faq/>}/>     
      <Route path = "/privacy" element = {<PrivacyPolicy/>}/>
      <Route path = "/terms" element = {<TermsAndConditions/>}/>
      </Routes>
    </div>
  );
}

export default App;
