import { FiLogOut } from 'react-icons/fi'; // Import the icons you need
import '../Assets/Styles/Sidebar.css';
import { Link } from 'react-router-dom';
import React, { useState } from 'react';
import {BsFillPersonLinesFill,BsFillPersonPlusFill} from 'react-icons/bs';
import {SlSocialSkype} from 'react-icons/sl';
import {BiMessageAdd} from 'react-icons/bi';
import {MdOutlineSubject} from 'react-icons/md';
import {PiTrademarkRegisteredLight} from 'react-icons/pi';
import {VscFeedback} from 'react-icons/vsc';
import {RiFeedbackFill} from 'react-icons/ri';
import { useNavigate } from 'react-router-dom'
import {AiFillFolderAdd} from 'react-icons/ai';
import {MdOutlinePlaylistAdd} from 'react-icons/md';

function Sidebar() {
  const [activeDropdown, setActiveDropdown] = useState(null);

  const toggleDropdown = (section) => {
    setActiveDropdown(section === activeDropdown ? null : section);
  };

  const logoutHandler = () => {
    localStorage.clear();
    // Handle your logout logic here
  };

  return (
    <div className="sidebar">
      <div className="logo-wrapper">
        <h3>Admin</h3>
      </div>
      <ul className="sidebar-menu">
        <li>
          <Link
            className={`nav-link ${activeDropdown === 'student' ? 'active' : ''}`}
            onClick={() => toggleDropdown('student')}
          >
            <span className="icon">
              <BsFillPersonLinesFill />
            </span>
            Student
          </Link>
          {activeDropdown === 'student' && (
            <ul className="dropdown-menu">
              <li>
                <Link to="/admin/student/add">
                  <BsFillPersonPlusFill /> Add Student
                </Link>
              </li>
              <li>
                <Link to="/admin/student/view">
                  <BsFillPersonLinesFill /> View Students
                </Link>
              </li>
            </ul>
          )}
        </li>
        <li>
          <Link
            className={`nav-link ${activeDropdown === 'subject' ? 'active' : ''}`}
            onClick={() => toggleDropdown('subject')}
          >
            <span className="icon">
              <SlSocialSkype />
            </span>
            Subject
          </Link>
          {activeDropdown === 'subject' && (
            <ul className="dropdown-menu">
              <li>
                <Link to="/admin/subject/addSub">
                  <BiMessageAdd /> Add Subject
                </Link>
              </li>
              <li>
                <Link to="/admin/subject/view">
                  <MdOutlineSubject /> View Subjects
                </Link>
              </li>
            </ul>
          )}
        </li>
        <li>
          <Link
            className={`nav-link ${activeDropdown === 'result' ? 'active' : ''}`}
            onClick={() => toggleDropdown('result')}
          >
            <span className="icon">
              <PiTrademarkRegisteredLight />
            </span>
            Result
          </Link>
          {activeDropdown === 'result' && (
            <ul className="dropdown-menu">
              <li>
                <Link to="/admin/result/addRes">
                  <AiFillFolderAdd/>
                  Add Result</Link>
              </li>
              <li>
                <Link to="/admin/result/viewRes">
                  <MdOutlinePlaylistAdd/>View Results</Link>
              </li>
            </ul>
          )}
        </li>
        <li>
          <Link
            className={`nav-link ${activeDropdown === 'feedback' ? 'active' : ''}`}
            onClick={() => toggleDropdown('feedback')}
          >
            <span className="icon">
              <VscFeedback />
            </span>
            Feedback
          </Link>
          {activeDropdown === 'feedback' && (
            <ul className="dropdown-menu">
              <li>
                <Link to="/admin/feedback/viewFeed">
                  <RiFeedbackFill /> View Feedback
                </Link>
              </li>
            </ul>
          )}
        </li>
        <li>
          <Link to="/" className="nav-link active" onClick={logoutHandler}>
            <FiLogOut />&nbsp;&nbsp;Logout
          </Link>
        </li>
      </ul>
    </div>
  );
}

export default Sidebar;