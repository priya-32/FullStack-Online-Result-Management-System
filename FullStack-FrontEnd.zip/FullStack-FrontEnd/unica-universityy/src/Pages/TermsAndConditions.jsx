import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../Components/Navbar';

function TermsAndConditions() {
  return (
    <>
      <Navbar />
      <div className='wr1'>
        <div className='privacy-policy-container'>

          <h2 className='section-heading'>Terms and Conditions</h2>

            <div className='section-term'>
              <h3>1. Acceptance of Terms</h3>
              <p>
                By accessing or using the Student Result Management System 
                you agree to comply with and be bound by these Terms and Conditions.
                If you do not agree to these Terms and Conditions, please do not use the System.
              </p>
            </div>

            <div className='section-term'>
              <h3>2. User Accounts</h3>
              <p>
                Access to the System is provided to registered users, including
                students, faculty, and administrative staff.
              </p>
              <p>Users are responsible for maintaining the confidentiality of their login credentials.</p>
              <p>Users must not share their login credentials with others.</p>
              <p>Unauthorized use of another user's account is strictly prohibited.</p>
            </div>

            <div className='section-term'>
              <h3>3. Use of the System</h3>
              <p>The System is intended for educational purposes only.</p>
              <p>Users must not use the System for any unlawful or malicious activities.</p>
              <p>Users must not attempt to compromise the security of the System.</p>
              <p>Users must not upload, share, or transmit any content that is defamatory, offensive, or violates the rights of others.</p>
            </div>

            {/* Repeat similar structures for the rest of the content sections */}

            <div className='section-term'>
              <h3>4. Governing Law</h3>
              <p>These Terms and Conditions are governed by the laws of [Your Jurisdiction].</p>
            </div>

            <div className='section-term'>
              <h3>5. Contact Information</h3>
              <p>For inquiries or concerns regarding these Terms and Conditions, please contact [Contact Email].</p>
            </div>

        </div>
      </div>
    </>
  );
}

export default TermsAndConditions;
