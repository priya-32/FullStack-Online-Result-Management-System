import "./Widget.css";
import { useState, useEffect } from "react";
import { AiOutlineTrademark } from "react-icons/ai";
import { SiGoogleclassroom } from "react-icons/si";
import { VscFeedback } from "react-icons/vsc";
import { PiStudentFill } from "react-icons/pi";
import { getStudentCount,getResultCount,getSubjectCount,getFeedbackCount }  from "../../../service/api";
const Widget = ({ type }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const fetchCount = async () => {
      try {
        let response;

        // Adjust the API endpoint based on your server implementation
        switch (type) {
          case "user":
            response = await getStudentCount();
            break;
          case "order":
            response = await getResultCount();
            break;
          case "earning":
            response = await getSubjectCount();
            break;
          case "balance":
            response = await getFeedbackCount();
            break;
          default:
            break;
        }
        console.log('Full API Response:', response);

        if (response && response.status === 200) {
          // Check if the response is valid JSON
          if (response.headers['content-type'].includes('application/json')) {
            const data = response.data;
            setCount(data.count);
          } else {
            console.error('Invalid JSON response:', response);
          }
        } else {
          console.error(`Unexpected response for ${type}:`, response);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchCount();
  }, [type]);

  let data;

  switch (type) {
    case "user":
      data = {
        title: "STUDENTS",
        isMoney: false,
        link: "Add Students Database",
        icon: <PiStudentFill className="icon" style={{ fontSize: "50px" }} />,
      };
      break;
    case "order":
      data = {
        title: "RESULTS",
        isMoney: false,
        link: "Add Results Details",
        icon: (
          <AiOutlineTrademark
            className="icon"
            style={{ fontSize: "50px" }}
          />
        ),
      };
      break;
    case "earning":
      data = {
        title: "SUBJECT",
        isMoney: false,
        link: "Add Subject Details",
        icon: (
          <SiGoogleclassroom
            className="icon"
            style={{ fontSize: "50px" }}
          />
        ),
      };
      break;
    case "balance":
      data = {
        title: "FEEDBACK",
        isMoney: false,
        link: "View Feedback",
        icon: (
          <VscFeedback
            className="icon"
            style={{ color: "black", fontSize: "50px" }}
          />
        ),
      };
      break;
    default:
      break;
  }

  return (
    <div className="widget">
      <div className="left">
        <span className="title">{data.title}</span>
        <span className="counter">{data.isMoney && "$"} {count}</span>
        <span className="link">{data.link}</span>
      </div>
      <div className="right">{data.icon}</div>
    </div>
  );
};

export default Widget;

