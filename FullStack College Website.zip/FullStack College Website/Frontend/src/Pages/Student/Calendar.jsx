import React, { useState, useEffect } from 'react';
import './Calendar.css';

const Calendar = () => {
  const currentDate = new Date();
  const [currentYear, setCurrentYear] = useState(currentDate.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(currentDate.getMonth());
  const [currentDay, setCurrentDay] = useState(currentDate.getDate());
  const [daysInMonth, setDaysInMonth] = useState(0);

  useEffect(() => {
    // Update the daysInMonth when the currentMonth or currentYear changes
    setDaysInMonth(new Date(currentYear, currentMonth + 1, 0).getDate());
  }, [currentMonth, currentYear]);

  const renderCalendar = () => {
    let calendarDays = [];
    let week = [];

    for (let i = 1; i <= daysInMonth; i++) {
      let dayClassName = 'calendar__day-number';
      if (i === currentDay && currentMonth === currentDate.getMonth() && currentYear === currentDate.getFullYear()) {
        dayClassName += ' calendar__day-number--current';
      }

      const day = (
        <span key={i} className={dayClassName}>
          {i}
        </span>
      );

      week.push(day);

      if (new Date(currentYear, currentMonth, i).getDay() === 6 || i === daysInMonth) {
        calendarDays.push(
          <div key={i} className="calendar__day-numbers-row">
            {week}
          </div>
        );

        if (i !== daysInMonth) {
          week = [];
        }
      }
    }

    return calendarDays;
  };

  return (
    <div className="calendar">
      <header className="calendar__header">
        <div className="calendar__month">{months[currentMonth]}</div>
        <div className="calendar__year">{currentYear}</div>
      </header>
      <div className="calendar__grid">
        <div className="calendar__day-names">
          <span className="calendar__day-name">S</span>
          <span className="calendar__day-name">M</span>
          <span className="calendar__day-name">T</span>
          <span className="calendar__day-name">W</span>
          <span className="calendar__day-name">T</span>
          <span className="calendar__day-name">F</span>
          <span className="calendar__day-name">S</span>
        </div>
        <div className="calendar__day-numbers">{renderCalendar()}</div>
      </div>
    </div>
  );
};

const months = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export default Calendar;
