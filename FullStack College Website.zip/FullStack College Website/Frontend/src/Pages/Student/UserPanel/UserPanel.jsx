import React from 'react'
import Sidebar from '../Sidebar/Sidebar'
import Chart from '../Card/Card'
import Performance from '../../Admin/Performance/Performance'
import Navbar1 from '../Navbar/Navbar'
import Calendar from '../Calendar'
import BarChart from '../BarChart';

import './UserPanel.css';
import Widget from '../Widget/Widget'
const UserPanel = () => {
  return (
    <div className="home">
      <Sidebar />
      <div className="homeContainer">
        <Navbar1 />
        <div className="widgets">
          <Widget type="user" />
          <Widget type="order" />
          <Widget type="earning" />
          <Widget type="balance" />
        </div>
        <div className="charts">
          <Calendar/>
        <div className='bar-chart'>
           <BarChart/>
           </div>
        </div>
        {/* <div className="listContainer">
          <div className="listTitle">Latest Transactions</div>
          <Table />
        </div> */}
      </div>
    </div>
  )
}

export default UserPanel
