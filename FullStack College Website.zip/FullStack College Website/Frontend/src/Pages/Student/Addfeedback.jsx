import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { addFeedback } from '../../service/api';
import { ToastContainer, toast } from 'react-toastify';
import { ChevronLeftCircle } from 'lucide-react';
 import './AddFeedback.css';
import 'react-toastify/dist/ReactToastify.css'; // Import the CSS for react-toastify
function Addfeedback() {
  const navigate = useNavigate();
  const [formdata, setFormdata] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    
  });
  
  const handleChange = (e) => {
    e.preventDefault();
    setFormdata({ ...formdata, [e.target.id]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const FeedbackData = {
        ...formdata,
      };
      console.log(FeedbackData);
      const res = await addFeedback(FeedbackData);
      console.log(res);
      if (res.status === 201) {
        toast.success(`Feedback Added Successfully !`, {
          position: 'bottom-right',
          autoClose: 4000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: 'light',
        });
        setTimeout(() => {
          navigate('/user/dashboard');
        }, 1000);
      }
    } catch (error) {
      toast.error(`Can't add the same subject twice!`, {
        position: 'bottom-right',
        autoClose: 4000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: 'light',
      });
    }
  };
  const routeBack = () => {
    navigate(-1)
  }
  return (
    <div className='content-wrapperfd'>
      <div className='add-feedback-container'>
        <h2>Add Feedback</h2>
        <form onSubmit={handleSubmit}>
          <div className='form-group'>
            <label htmlFor='name'>Name:</label>
            <input
              type='text'
              id='name'
              onChange={handleChange}
              required
            />
          </div>
          <div className='form-group'>
            <label htmlFor='email'>Email:</label>
            <input
              type='email'
              id='email'
              onChange={handleChange}
              required
            />
          </div>
          <div className='form-group'>
            <label htmlFor='subject'>Subject:</label>
            <input
              type='text'
              id='subject'
              onChange={handleChange}
              required
            />
          </div>
          <div className='form-group'>
            <label htmlFor='message'>Message:</label>
            <textarea
              id='message'
              onChange={handleChange}
              required
            />
          </div>
         {/* ... (previous JSX) */}
         <div className="rt ">
    <button onClick={routeBack} className="route-btn12">
      Back
    </button>
   &nbsp;
    <button type="submit">Add Feedback</button>
  </div>
{/* ... (remaining JSX) */}

        </form>
      </div>
      <ToastContainer
        position='bottom-right'
        autoClose={4000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme='light'
      />
      
    </div>
  );
}

export default Addfeedback;
