import React, { useEffect, useRef,useState } from 'react';
import Chart from 'chart.js/auto'; // Import the Chart.js library

const BarChart = () => {
  useEffect(() => {
    // Get the canvas element
    const ctx = document.getElementById("barChart").getContext('2d');

    // Create the bar chart
    const barChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ["2016", "2017", "2018", "2019", "2020", "2021", "2022"],
        datasets: [{
          label: 'Year',
          data: [12, 19, 13, 17, 16, 24, 17],
          backgroundColor: "skyblue"
        }, {
          label: 'Student',
          data: [10, 22, 15, 14, 20, 13, 10],
          backgroundColor: "rgba(0,0,255,1)"
        }]
      }
    });

    // Cleanup on component unmount
    return () => {
      barChart.destroy();
    };
  }, []); // Empty dependency array ensures that this effect runs once after the initial render

  return (
    <main className="container">
      <h2>Average Grade By Year </h2>
      <div>
        <canvas id="barChart"></canvas>
      </div>
    </main>
  );
};

export default BarChart;
