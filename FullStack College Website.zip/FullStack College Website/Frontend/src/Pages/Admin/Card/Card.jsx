import "./Card.css";
import { IoIosArrowUp } from 'react-icons/io';
import { FaUser, FaShoppingCart, FaMoneyBill, FaWallet } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import axios from 'axios'; // Assuming you are using Axios for HTTP requests

const Card = ({ type }) => {
  const navigate = useNavigate();
  const [count, setCount] = useState(0);

  useEffect(() => {
    // Define an async function to fetch data based on the provided type
    const fetchData = async () => {
      try {
        let response;

        // Adjust the API endpoint based on your server implementation
        switch (type) {
          case 'user':
            response = await axios.get('/api/users/count');
            break;
          case 'order':
            response = await axios.get('/api/orders/count');
            break;
          case 'earning':
            response = await axios.get('/api/earnings/count');
            break;
          case 'balance':
            response = await axios.get('/api/balance/count');
            break;
          default:
            break;
        }

        // Set the count based on the response data
        setCount(response.data.count);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    // Call the fetchData function
    fetchData();
  }, [type]);

  let data;

  switch (type) {
    case "user":
      data = {
        title: 'STUDENTS',
        isMoney: false,
        icon: (
          <FaUser
            className="icon"
            style={{
              color: 'crimson',
              backgroundColor: 'rgba(255, 0, 0, 0.2)',
            }}
          />
        ),
      };
      break;
    case 'order':
      data = {
        title: 'ORDERS',
        isMoney: false,
        link: 'View all orders',
        icon: (
          <FaShoppingCart
            className="icon"
            style={{
              backgroundColor: 'rgba(218, 165, 32, 0.2)',
              color: 'goldenrod',
            }}
          />
        ),
      };
      break;
    case 'earning':
      data = {
        title: 'EARNINGS',
        isMoney: false,
        link: 'View net earnings',
        icon: (
          <FaMoneyBill
            className="icon"
            style={{ backgroundColor: 'rgba(0, 128, 0, 0.2)', color: 'green' }}
          />
        ),
      };
      break;
    case 'balance':
      data = {
        title: 'BALANCE',
        isMoney: false,
        link: 'See details',
        icon: (
          <FaWallet
            className="icon"
            style={{
              backgroundColor: 'rgba(128, 0, 128, 0.2)',
              color: 'green',
            }}
          />
        ),
      };
      break;
    default:
      break;
  }

  return (
    <div className="widget">
      <div className="left">
        <span className="title">{data.title}</span>
        <span className="counter">
          {data.isMoney } {count}
        </span>
        <span className="link">{data.link}</span>
      </div>
      <div className="right12">
        {data.icon}
      </div>
    </div>
  );
};

export default Card;
