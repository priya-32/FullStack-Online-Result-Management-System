import React, { useEffect, useState } from 'react';

const Progress = ({ percent, duration }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (progress < percent) {
        setProgress((prevProgress) => prevProgress + 1);
      }
    }, duration / percent);

    return () => clearInterval(interval);
  }, [percent, duration, progress]);

  return (
    <div className="progress-container">
      <div className="my-progress-bar" style={{ transform: `rotate(${(progress / 100) * 360}deg)` }}>
        <div
          className="progress-circle"
          style={{
            width: '100%',
            height: '100%',
            clipPath: `polygon(50% 0%, 100% 0%, 100% 100%, 50% 100%, 50% 0%, ${50 + progress}% 0%, ${50 + progress}% 100%, 50% 100%)`,
            backgroundColor: '#0ff',
            transition: `clip-path ${duration}ms linear`,
          }}
        />
      </div>
      <div className="progress-percentage">{progress}%</div>
    </div>
  );
};

export default Progress;
