import React from 'react';
import { FaEllipsisV, FaArrowDown, FaArrowUp } from 'react-icons/fa';
import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import './Performance.css';
const Performance = () => {
  return (
    <div className="performance">
      <div className="top">
        <h1 className="title">Total Admission</h1>
        <FaEllipsisV className="icon" fontSize={"small"} />
      </div>
      <div className="bottom">
        <div className="featuredChart">
          <CircularProgressbar value={70} text={"70%"} strokeWidth={3} />
        </div>
        <p className="title">Total Students Joined This year</p>
        <p className="amount">1820</p>
        <p className="desc">
          
        </p>
        <div className="summary">
          <div className="item">
            <div className="itemTitle">2021</div>
            <div className="itemResult negative">
              <FaArrowDown className="icon" />
              <div className="resultAmount">1200</div>
            </div>
          </div>
          <div className="item">
            <div className="itemTitle">2022</div>
            <div className="itemResult positive">
              <FaArrowUp className="icon" />
              <div className="resultAmount">1700</div>
            </div>
          </div>
          <div className="item">
            <div className="itemTitle">2023</div>
            <div className="itemResult positive">
              <FaArrowUp className="icon" />
              <div className="resultAmount">1820</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Performance;
