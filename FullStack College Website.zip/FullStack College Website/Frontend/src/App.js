import logo from './logo.svg';
import './App.css';
import Navbar from './Components/Navbar';
import {Routes, Route } from "react-router-dom"
import Mainpage from './Pages/Mainpage';
import Home from './Pages/Home';
import SocialShareMenu from './Pages/SocialShareMenu';
import Aboutus from './Pages/Aboutus';
import { ContactUs } from './Pages/Contactus';
import BlogList from './Pages/BlogList';
import Department from './Pages/department';
import Academics from './Pages/Academics';
import LoginForm from './Pages/Login';
import Register from './Pages/Register';
import Home2 from './Pages/Admin/Home/Home';
import UserPanel from './Pages/Student/UserPanel/UserPanel';
import Faq from './Faq';
import PrivacyPolicy from './Pages/PrivacyPolicy';
import TermsAndConditions from './Pages/TermsAndConditions';
import { UserAuth } from './Pages/Student/Auth/UserAuth';
import ViewStudent1 from './Pages/Student/ViewStudent';
import ViewResult1 from './Pages/Student/ViewResult';
import ViewSubject1 from './Pages/Student/ViewSubject1';
import Addfeedback from './Pages/Student/Addfeedback';

function App() {
  return (
    <div className="App">

      <Routes>
        
<Route path = "/" element = {<Home/>}/>
<Route path = "/contact" element = {<ContactUs/>}/>
<Route path = "/about" element = {<Aboutus/>}/>
<Route path='/blog' element = {<BlogList/>}/>
<Route path = "/academics" element = {<Academics/>}/>
<Route path = "/login" element = {<LoginForm/>}/>
      <Route  path='/register' element={<Register />} />
      <Route exact path = "/admin/dashboard" element = {<Home2/>}/>
      <Route element={<UserAuth />}>
          <Route exact path="/user/dashboard" element={<UserPanel />} />
          <Route exact path='/user/student/view' element={<ViewStudent1 />} />
          <Route exact path='/user/result/view' element={<ViewResult1 />} />
          <Route exact path='/user/subject/view' element={<ViewSubject1 />} />
          <Route exact path='/user/feedback/add' element={<Addfeedback />} />
        </Route>
      <Route path = "/faq" element = {<Faq/>}/>     
      <Route path = "/privacy" element = {<PrivacyPolicy/>}/>
      <Route path = "/terms" element = {<TermsAndConditions/>}/>
      </Routes>
    </div>
  );
}

export default App;
